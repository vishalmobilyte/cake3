<?php
header('Location: /');
exit;
?>