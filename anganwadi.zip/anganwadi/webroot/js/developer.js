$(function(){
	$("input[name='phone']").attr('maxlength',10);
})
  
/*  
  $( document ).ready(function() {
    $("#issued-date").datepicker(
           {
         changeMonth: true,
         changeYear: true,
           maxDate: new Date(),
           yearRange: "-70:-18",
       dateFormat: 'yy-mm-dd'
       //defaultDate: '01-01-1998',
      

       }
      );
    $("#issued-date").click(function(){ $("#issued-date").focus();});

    $("#expiary-date").datepicker(
           {
         changeMonth: true,
         changeYear: true,
          
           yearRange: "-70:-18",
       dateFormat: 'yy-mm-dd'
  
      

       }
      );
    $("#expiary-date").click(function(){ $("#expiary-date").focus();});
  });

*/
