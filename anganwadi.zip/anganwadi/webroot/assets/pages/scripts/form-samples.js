var FormSamples = function () {


    return {
        //main function to initiate the module
        init: function () {

        }

    };

}();

jQuery(document).ready(function() {
    FormSamples.init();
});