<p><span style="font-family: Arial,Helvetica,sans-serif;">&nbsp;</span></p>
<table style="border-collapse: collapse; border-spacing: 0; border: 1px solid #2B3643; background-color: #fff; padding: 0;" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr style="height: 36px;" height="36">
<td style="width: 30px; background-color: #2B3643;" width="30" valign="middle"><span style="background-color: #2B3643;">&nbsp;</span></td>
<td style="width: 500px; background-color: #2B3643;" width="500" valign="middle"><span style="background-color: #2B3643;"><span style="color: white; font-size: small;"><strong>Sky2c- Password Reset</strong></span></span></td>
<td style="width: 30px; background-color: #2B3643;" width="30" valign="middle"><span style="background-color: #2B3643;">&nbsp;</span></td>
</tr>
<tr>
<td style="height: 20px;" colspan="3" valign="top"><br /></td>
</tr>
<tr>
<td style="width: 30px;" width="30" valign="top"><br /></td>
<td style="width: 500px;" width="500" valign="top"><span style="font-family: Arial,Helvetica,sans-serif;"> 
<table style="border-collapse: collapse; border-spacing: 0; padding: 0;" border="0" cellspacing="0" cellpadding="0" width="499" height="108" align="left">
<tbody>
<tr>
<td valign="top"><img style="display: block; margin-left: auto; margin-right: auto;" src="/sitterguide/img/front/mobile_nav_logo.png" alt="" /><br /></td>
</tr>
<tr>
<td valign="top"><br /></td>
</tr>
<tr>
<td valign="top">Hello {full_name},</td>
</tr>
<tr>
<td style="height: 25px;" valign="top"><br /></td>
</tr>
<tr>
<td valign="top">
<p>Your password has been reset successfully.&nbsp;</p>
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td class="system_contmail" colspan="2">If you any query please let us know straight away at:<a href="contatorodrigobrandao@gmail.com"> contatorodrigobrandao@gmail.com</a></td>
</tr>
</tbody>
</table>
</span></td>
<td style="width: 30px;" width="30" valign="top"><br /></td>
</tr>
<tr>
<td style="height: 20px;" colspan="3" valign="top"><br /></td>
</tr>
<tr>
<td style="width: 30px; background-color: #2B3643;" width="30" valign="top"><br /></td>
<td style="background-color: #2B3643; padding: 15px 0;" valign="top"><span style="background-color: #2B3643;"><span style="font-family: Arial,Helvetica,sans-serif;"> 
<table style="border-collapse: collapse; border-spacing: 0; text-align: justify; padding: 0;" border="0" cellspacing="0" cellpadding="0" align="left">
<tbody style="color:#fff">
<tr>
<td style="width: 500px; height: 20px;" width="500" valign="top">
<p style="font-weight: bold;">Regards,<br /> Team Sky2c</p>
<hr />
<p><span style="font-family: Arial; font-size: xx-small;">Notice:  The information in this email and in any  attachments is confidential  and intended solely for the attention and use of the  named addressee.  This information may be subject to legal professional or other   privilege or may otherwise be protected by work product immunity or  other legal  rules. It must not be disclosed to any person without  authorization. If you are  not the intended recipient, or a person  responsible for delivering it to the  intended recipient, you are not  authorized to and must not disclose, copy,  distribute, or retain this  message or any part of  it.</span></p>
</td>
</tr>
</tbody>
</table>
</span></span></td>
<td style="width: 30px; background-color: #2B3643;" width="30" valign="top"><br /></td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>