16-02-2017
-----------
ALTER TABLE `users` CHANGE `phone` `phone` VARCHAR( 20 ) NULL DEFAULT NULL ;