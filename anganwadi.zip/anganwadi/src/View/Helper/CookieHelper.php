<?php
use Cake\View\Helper;

class CookieHelper extends Helper
{

}

?>