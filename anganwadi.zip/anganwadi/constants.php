<?php 
  /**
  *All
  *constants
  *
  */

// define("WOWZA_DOMAIN",'http://199.189.86.19:8182/');
define("WOWZA_DOMAIN",'http://209.126.105.148:8182/');

define("MAIN_HTTP_ROOT", "http://sonoclickapp.com.br/dev/");
// define("MAIN_WOWZA_DOMAIN", "http://199.189.86.19:8182/");
define("MAIN_WOWZA_DOMAIN", "http://209.126.105.148/:8182/");
define("DB_HOST", "localhost");
define("DB_NAME", "mobilyte_sonoclick_dev");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "Thor1234!");

define("FB_APP_ID", "2062249554001852");
define("FB_APP_SECRET", "5f31ba0e18672a0230059e4677fcbb7b");

?>
<script>
//var main_wowza_domain = "http://199.189.86.19:8182/"; 
var main_wowza_domain = "http://209.126.105.148/:8182/"; 
</script>